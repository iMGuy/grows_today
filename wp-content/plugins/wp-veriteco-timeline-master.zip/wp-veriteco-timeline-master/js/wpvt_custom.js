jQuery(document).ready(function(){
    jQuery(function() {
		jQuery( ".datepicker" ).datepicker({ dateFormat: 'yy,m,d' });
	});
});